const contenedor = document.getElementById('contenedor');

const generos = {
  "Fantasía": ["- Magia y mundos imaginarios", "- Fantasía épica", "- Criaturas mágicas"],
  "Romance": ["- Novelas de amor contemporáneo", "- Romance histórico", "- Romance juvenil"],
  "Ciencia Ficción": ["- Viajes espaciales", "- Universos alternativos", "- Futurismo y tecnología"],
  "Ficción Histórica": ["- Novelas sobre eventos históricos", "- Historias reales con ficción", "- Novelas de guerra y aventuras"],
  "Historia Real": ["- Biografías", "- Ensayos históricos", "- Documentales escritos"]
};

let nombre = '';
let edad = '';
let idioma = '';
let generoSeleccionado = '';

function preguntarNombre() {
  contenedor.innerHTML = `
    <div class="card">
      <h2>¿Cuál es tu nombre?</h2>
      <input type="text" id="nombreInput" placeholder="Escribe tu nombre">
      <button class="button" onclick="guardarNombre()">Continuar</button>
    </div>
  `;
}

function guardarNombre() {
  const input = document.getElementById('nombreInput').value.trim();
  if (input !== '') {
    nombre = input;
    preguntarEdad();
  } else {
    alert('Por favor escribe tu nombre.');
  }
}

function preguntarEdad() {
  contenedor.innerHTML = `
    <div class="card">
      <h2>Hola ${nombre}, ¿cuántos años tienes?</h2>
      <input type="number" id="edadInput" placeholder="Escribe tu edad">
      <button class="button" onclick="guardarEdad()">Continuar</button>
    </div>
  `;
}

function guardarEdad() {
  const input = document.getElementById('edadInput').value.trim();
  if (input !== '' && Number(input) > 0) {
    edad = input;
    preguntarIdioma();
  } else {
    alert('Por favor ingresa una edad válida.');
  }
}

function preguntarIdioma() {
  contenedor.innerHTML = `
    <div class="card">
      <h2>¿Qué idioma prefieres, ${nombre}?</h2>
      <button class="button" onclick="guardarIdioma('Español')">Español</button>
      <button class="button" onclick="guardarIdioma('Inglés')">Inglés</button>
    </div>
  `;
}

function guardarIdioma(idiomaSeleccionado) {
  idioma = idiomaSeleccionado;
  preguntarGenero();
}

function preguntarGenero() {
  contenedor.innerHTML = `<div class="card"><h2>${nombre}, ¿qué género prefieres?</h2></div>`;
  const card = contenedor.querySelector('.card');
  Object.keys(generos).forEach(genero => {
    const btn = document.createElement('button');
    btn.textContent = genero;
    btn.classList.add('button');
    btn.onclick = () => mostrarRecomendaciones(genero);
    card.appendChild(btn);
  });
}

function mostrarRecomendaciones(genero) {
  generoSeleccionado = genero;
  const recomendaciones = generos[genero].map(item => `<li>${item}</li>`).join('');
  contenedor.innerHTML = `
    <div class="card">
      <h2>Recomendaciones para ti, ${nombre}</h2>
      <p><strong>${genero}</strong></p>
      <ul>${recomendaciones}</ul>
      <button class="button" onclick="preguntarLibro()">¿Quieres la recomendación de un libro?</button>
      <button class="button" onclick="reiniciar()">Elegir otro género</button>
    </div>
  `;
}

function preguntarLibro() {
  contenedor.innerHTML += `
    <div class="card">
      <h3>¿Quieres un libro específico?</h3>
      <button class="button" onclick="recomendarLibro()">Sí</button>
      <button class="button" onclick="gracias()">No</button>
    </div>
  `;
}

function recomendarLibro() {
  contenedor.innerHTML += `
    <div class="card">
      <h3>Libro Recomendado</h3>
      <p><em>'Libro destacado de ${generoSeleccionado}'</em></p>
      <button class="button" onclick="reiniciar()">Volver a empezar</button>
    </div>
  `;
}

function gracias() {
  contenedor.innerHTML += `
    <div class="card">
      <p>¡Gracias por visitar nuestra biblioteca, ${nombre}!</p>
      <button class="button" onclick="reiniciar()">Volver a empezar</button>
    </div>
  `;
}

function reiniciar() {
  nombre = '';
  edad = '';
  idioma = '';
  generoSeleccionado = '';
  preguntarNombre();
}

// Iniciar la experiencia
preguntarNombre();
